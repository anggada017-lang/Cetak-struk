package com.mayacetakstruk.dana;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  EditText sharedText,idPel,nama,token,kwh,bayar,admin; TextView preview,status;
  BluetoothAdapter bt; BluetoothDevice printer; OutputStream out;
  final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  static final int REQ=10;
  @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
    sharedText=findViewById(R.id.sharedText); idPel=findViewById(R.id.idPel); nama=findViewById(R.id.nama); token=findViewById(R.id.token); kwh=findViewById(R.id.kwh); bayar=findViewById(R.id.bayar); admin=findViewById(R.id.admin); preview=findViewById(R.id.preview); status=findViewById(R.id.status);
    bt=BluetoothAdapter.getDefaultAdapter();
    findViewById(R.id.selectPrinter).setOnClickListener(v->choosePrinter());
    findViewById(R.id.parse).setOnClickListener(v->{parse(); makePreview();});
    findViewById(R.id.print).setOnClickListener(v->{parse(); makePreview(); printReceipt();});
    handleIntent(getIntent());
    if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ);
  }
  @Override protected void onNewIntent(Intent i){super.onNewIntent(i); setIntent(i); handleIntent(i);}
  void handleIntent(Intent i){ if(i!=null && Intent.ACTION_SEND.equals(i.getAction())){CharSequence s=i.getCharSequenceExtra(Intent.EXTRA_TEXT); if(s==null) s=i.getCharSequenceExtra(Intent.EXTRA_TITLE); if(s!=null){sharedText.setText(s); parse(); makePreview();}} }
  void choosePrinter(){
    if(bt==null){toast("HP tidak mendukung Bluetooth");return;}
    if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ);return;}
    Set<BluetoothDevice> ds=bt.getBondedDevices(); final ArrayList<BluetoothDevice> list=new ArrayList<>(ds);
    if(list.isEmpty()){toast("Pair MP-58ECO dulu di Pengaturan Bluetooth Android");return;}
    String[] names=new String[list.size()]; for(int i=0;i<list.size();i++) names[i]=list.get(i).getName()+"\n"+list.get(i).getAddress();
    new AlertDialog.Builder(this).setTitle("Pilih printer").setItems(names,(d,w)->{printer=list.get(w); status.setText("Printer: "+printer.getName()); connect();}).show();
  }
  void connect(){new Thread(()->{try{BluetoothSocket s=printer.createRfcommSocketToServiceRecord(SPP); s.connect(); out=s.getOutputStream(); runOnUiThread(()->toast("Printer terhubung"));}catch(Exception e){runOnUiThread(()->toast("Gagal terhubung: "+e.getMessage()));}}).start();}
  void parse(){String t=sharedText.getText().toString(); if(t.trim().isEmpty())return;
    Matcher m=Pattern.compile("(\\d{4}(?:\\s+\\d{4}){4})").matcher(t); if(m.find())token.setText(m.group(1));
    m=Pattern.compile("\\b\\d{10,16}\\b").matcher(t); if(m.find())idPel.setText(m.group());
    m=Pattern.compile("(\\d+[.,]\\d+)\\s*kwh",Pattern.CASE_INSENSITIVE).matcher(t); if(m.find())kwh.setText(m.group(1));
    m=Pattern.compile("Rp\\s*([\\d.]+)",Pattern.CASE_INSENSITIVE).matcher(t); if(m.find())bayar.setText(m.group(1).replace(".",""));
  }
  String val(EditText e){return e.getText().toString().trim();}
  String money(String s){try{return String.format(Locale.US,"%,d",Long.parseLong(s)).replace(',','.');}catch(Exception e){return "0";}}
  String makeReceipt(){String t=sharedText.getText().toString().toLowerCase(); boolean tok=t.contains("token")||t.contains("kwh")||!val(token).isEmpty(); boolean tarik=t.contains("tarik"); String title=tok?"STRUK TOKEN LISTRIK PLN":(tarik?"STRUK TARIK TUNAI":"STRUK TRANSAKSI"); StringBuilder x=new StringBuilder(); x.append("==============================\n").append(center(title)).append("\n==============================\n"); x.append("TGL        : ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.US).format(new Date())).append("\n"); x.append("------------------------------\n"); x.append("ID/NO      : ").append(val(idPel)).append("\nNAMA       : ").append(val(nama)).append("\n"); if(tok){x.append("TOKEN      :\n").append(val(token)).append("\nKWH        : ").append(val(kwh)).append("\n");} x.append("NOMINAL    : Rp ").append(money(val(bayar))).append("\n"); x.append("BIAYA ADMIN: Rp ").append(money(val(admin))).append("\n"); long a=0,b=0;try{a=Long.parseLong(val(bayar));}catch(Exception e){}try{b=Long.parseLong(val(admin));}catch(Exception e){} x.append("TOTAL BAYAR: Rp ").append(money(""+(a+b))).append("\n==============================\n").append(center("Terima Kasih")).append("\n==============================\n\n"); return x.toString();}
  String center(String s){int n=Math.max(0,(32-s.length())/2);StringBuilder z=new StringBuilder(); for(int i=0;i<n;i++) z.append(" "); return z.toString()+s;}
  void makePreview(){String r=makeReceipt();preview.setText(r);}
  void printReceipt(){if(out==null){toast("Pilih printer dan pastikan MP-58ECO sudah Pair");return;} final String r=makeReceipt(); new Thread(()->{try{byte[] init={0x1B,0x40};out.write(init);out.write(r.getBytes(Charset.forName("CP437")));out.write(new byte[]{0x1B,0x64,0x03});out.flush();runOnUiThread(()->toast("Struk terkirim ke printer"));}catch(Exception e){runOnUiThread(()->toast("Cetak gagal: "+e.getMessage()));}}).start();}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}

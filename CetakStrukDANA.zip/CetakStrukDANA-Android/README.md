# Cetak Struk DANA - Android

Aplikasi Android native untuk menerima teks transaksi dari menu Share Android dan mencetak ke printer thermal Bluetooth ESC/POS seperti MP-58ECO.

## Fitur
- Muncul di menu Share Android untuk `text/plain`.
- Ekstraksi sederhana token PLN, ID/no, kWh, dan nominal.
- Pair printer di Settings > Bluetooth, lalu pilih dari aplikasi.
- Cetak ESC/POS 32 kolom untuk printer 58 mm.
- Mengingat koneksi selama aplikasi aktif.

## Build tanpa Android Studio
1. Upload seluruh folder proyek ini ke repository GitHub.
2. Buka tab Actions.
3. Pilih workflow `Build APK`.
4. Tekan `Run workflow`.
5. Setelah selesai, buka hasil workflow dan download artifact `CetakStrukDANA-debug`.
6. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di HP.

## Penggunaan
1. Pair MP-58ECO di Pengaturan Bluetooth Android.
2. Buka aplikasi, pilih `Pilih Printer Bluetooth`.
3. Pilih MP-58ECO.
4. Dari DANA pilih Share > Cetak Struk DANA.
5. Periksa preview lalu tekan `CETAK KE MP-58ECO`.

Catatan: format transaksi DANA dapat berbeda-beda. Parser perlu disesuaikan dengan contoh teks Share DANA milik pengguna agar ekstraksi nama, nominal, ID, dan jenis transaksi 100% tepat.
